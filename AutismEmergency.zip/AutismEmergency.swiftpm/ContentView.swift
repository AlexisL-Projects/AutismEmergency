import SwiftUI

// MARK: - Panic Button
struct PanicButton: View {
    let item: MessageItem
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            Text(item.title)
                .multilineTextAlignment(.center)
                .font(.title3)
                .padding()
                .frame(maxWidth: .infinity, minHeight: 100)
                .background(Color.blue.opacity(0.18))
                .cornerRadius(16)
        }
        .accessibilityLabel(item.title)
    }
}

// MARK: - Hold-to-Confirm SOS Button
struct HoldToConfirmButton<Label: View>: View {
    let action: () -> Void
    let label: () -> Label
    
    @State private var progress: CGFloat = 0
    let duration: Double = 1.6
    
    var body: some View {
        ZStack {
            Capsule().fill(Color.gray.opacity(0.12)).frame(height: 60)
            Capsule()
                .fill(Color.red.opacity(0.22))
                .frame(width: 40 + progress*(UIScreen.main.bounds.width - 80), height: 60)
            label()
                .foregroundColor(.primary)
        }
        .gesture(
            LongPressGesture(minimumDuration: duration)
                .onEnded { _ in
                    action()
                    progress = 0
                }
        )
        .simultaneousGesture(
            DragGesture(minimumDistance: 0)
                .onChanged { g in
                    let w = UIScreen.main.bounds.width - 80
                    progress = max(0, min(1, g.location.x / w))
                }
                .onEnded { _ in progress = 0 }
        )
    }
}

// MARK: - Main ContentView
struct ContentView: View {
    @StateObject private var tts = TTSManager()
    
    let messages: [MessageItem] = [
        MessageItem(title: "I am overwhelmed 😣\nI need a break"),
        MessageItem(title: "I am autistic ♾️\nPlease be patient"),
        MessageItem(title: "I am nonverbal 🤐"),
        MessageItem(title: "I need space 🚶‍♂️💨"),
        MessageItem(title: "I need quiet 🤫🔕"),
        MessageItem(title: "I need my sensory tools 🎧🧸"),
        MessageItem(title: "I need help 🆘")
    ]
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 16) {
                    Text("Autism Panic — Quick Talk")
                        .font(.title2)
                        .bold()
                        .padding(.top)
                    
                    ForEach(messages) { item in
                        PanicButton(item: item) {
                            speakAndHaptic(item.title)
                        }
                    }
                    
                    HoldToConfirmButton(action: {
                        sosTriggered()
                    }, label: { Text("HOLD for SOS").bold() })
                    .padding(.horizontal)
                    .padding(.top, 20)
                }
                .padding()
            }
        }
        .onAppear {
            tts.rate = 0.45
        }
    }
    
    // MARK: - Speak + Haptic
    func speakAndHaptic(_ text: String) {
        tts.speak(text)
        HapticsManager.shared.playTap()
    }
    
    func sosTriggered() {
        tts.speak("Emergency. I need help. Please assist.")
        HapticsManager.shared.playWarning()
    }
}

// MARK: - Preview
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
