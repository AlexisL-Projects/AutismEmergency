import Foundation
import AVFoundation

final class TTSManager: ObservableObject {
    let synthesizer = AVSpeechSynthesizer()
    @Published var rate: Float = 0.45
    
    func speak(_ text: String) {
        stop()
        let cleanText = removingEmojis(from: text)
        let utterance = AVSpeechUtterance(string: cleanText)
        utterance.rate = rate
        
        // Safe English voice
        if let voice = AVSpeechSynthesisVoice.speechVoices().first(where: { $0.language.hasPrefix("en") }) {
            utterance.voice = voice
        }
        
        synthesizer.speak(utterance)
    }
    
    func stop() {
        if synthesizer.isSpeaking {
            synthesizer.stopSpeaking(at: .immediate)
        }
    }
}
