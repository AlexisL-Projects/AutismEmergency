import Foundation

// MARK: - Remove emojis helper
func removingEmojis(from text: String) -> String {
    text.unicodeScalars.filter { scalar in
        !(scalar.properties.isEmoji || scalar.value > 0x1F9FF)
    }.map { String($0) }.joined()
}

// MARK: - Message model
struct MessageItem: Identifiable {
    let id = UUID()
    let title: String
}
